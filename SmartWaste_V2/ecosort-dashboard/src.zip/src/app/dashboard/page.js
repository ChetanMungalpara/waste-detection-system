'use client';

import { useEffect, useState, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import Webcam from 'react-webcam';

const CATEGORY_ICONS = {
  'Recyclable': '🥤',
  'Organic': '🍎',
  'Hazardous': '🔋',
  'E-waste': '💻',
  'Unknown': '❓'
};

export default function DashboardPage() {
  const router = useRouter();
  const webcamRef = useRef(null);
  
  const [user, setUser] = useState(null);
  const [classifying, setClassifying] = useState(false);
  const [lastResult, setLastResult] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [cameraActive, setCameraActive] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem('ecoSortUser');
    const token = localStorage.getItem('ecoSortToken');
    if (!storedUser || !token) {
      router.push('/login');
    } else {
      setUser(JSON.parse(storedUser));
    }
  }, [router]);

  const captureAndClassify = useCallback(async () => {
    if (!webcamRef.current) return;
    const imageSrc = webcamRef.current.getScreenshot();
    if (!imageSrc) return;

    setClassifying(true); setLastResult(null); setErrorMsg('');

    try {
      const mlResponse = await fetch('http://localhost:5000/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: imageSrc }),
      });
      const mlData = await mlResponse.json();

      if (!mlResponse.ok) {
        setErrorMsg(mlData.error || 'Failed to detect waste.');
        setClassifying(false);
        return;
      }

      const token = localStorage.getItem('ecoSortToken');
      const tokenPayload = JSON.parse(atob(token.split('.')[1]));

      const dbResponse = await fetch('/api/add-points', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: tokenPayload.userId,
          itemDetected: mlData.item,
          category: mlData.category,
          points: mlData.points,
        }),
      });

      const dbData = await dbResponse.json();

      if (dbResponse.ok) {
        setLastResult(mlData);
        const updatedUser = { ...user, points: dbData.totalPoints, history: dbData.history };
        setUser(updatedUser);
        localStorage.setItem('ecoSortUser', JSON.stringify(updatedUser));
      }
    } catch (error) {
      setErrorMsg('API Connection Error. Ensure backend is running.');
    } finally {
      setClassifying(false);
    }
  }, [user]);

  if (!user) return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
       <div className="w-8 h-8 border-4 border-[#0f172a] border-t-transparent rounded-full animate-spin"></div>
    </div>
  );

  return (
    <div className="flex h-screen bg-slate-50 font-sans overflow-hidden">
      
      {/* Sidebar Navigation (Desktop) */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-slate-200 h-full p-6 justify-between">
        <div>
          <div className="flex items-center gap-3 mb-10">
            <div className="w-10 h-10 bg-[#0f172a] rounded-xl flex items-center justify-center text-white shadow-md">♻️</div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight">EcoSort.</h1>
          </div>
          
          <nav className="space-y-2">
            <a href="#" className="flex items-center gap-3 px-4 py-3 bg-slate-100 text-slate-900 rounded-xl font-bold text-sm">
              <span className="text-lg">📊</span> Overview
            </a>
            <a href="#" className="flex items-center gap-3 px-4 py-3 text-slate-500 hover:bg-slate-50 rounded-xl font-semibold text-sm transition-colors">
              <span className="text-lg">🏆</span> Leaderboard
            </a>
            <a href="#" className="flex items-center gap-3 px-4 py-3 text-slate-500 hover:bg-slate-50 rounded-xl font-semibold text-sm transition-colors">
              <span className="text-lg">⚙️</span> Settings
            </a>
          </nav>
        </div>

        <button 
          onClick={() => { localStorage.clear(); router.push('/login'); }}
          className="flex items-center gap-3 px-4 py-3 text-red-500 hover:bg-red-50 rounded-xl font-bold text-sm transition-colors w-full"
        >
          <span>🚪</span> Logout
        </button>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-full overflow-y-auto">
        
        {/* Top Header */}
        <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 px-6 sm:px-10 py-4 flex justify-between items-center sticky top-0 z-10">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Dashboard</h2>
            <p className="text-xs font-semibold text-slate-500 mt-0.5">Welcome back, {user.name.split(' ')[0]}</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-bold text-slate-900">{user.name}</p>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{user.lpuUid}</p>
            </div>
            <div className="w-10 h-10 bg-gradient-to-tr from-emerald-400 to-teal-500 rounded-full text-white flex items-center justify-center font-bold shadow-sm">
              {user.name.charAt(0)}
            </div>
          </div>
        </header>

        {/* Bento Grid Content */}
        <div className="p-6 sm:p-10 max-w-7xl mx-auto w-full">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Top Left: Points Card */}
            <div className="bg-[#0f172a] rounded-3xl p-8 text-white relative overflow-hidden shadow-xl lg:col-span-2">
              <div className="absolute right-0 top-0 w-64 h-64 bg-emerald-500 rounded-full mix-blend-overlay filter blur-[80px] opacity-40"></div>
              <div className="relative z-10 flex flex-col h-full justify-between">
                <div>
                  <p className="text-slate-400 font-bold uppercase tracking-widest text-xs mb-3">Total Rewards</p>
                  <h3 className="text-5xl sm:text-6xl font-black text-white mb-2">{user.points.toLocaleString()} <span className="text-2xl text-emerald-400">pts</span></h3>
                  <p className="text-sm text-slate-300 font-medium bg-white/10 inline-block px-3 py-1 rounded-full backdrop-blur-sm border border-white/5">
                    ≈ ₹{(user.points / 10).toFixed(2)} value
                  </p>
                </div>
                <div className="mt-8 flex gap-4">
                  <button className="px-6 py-3 bg-emerald-400 text-[#0f172a] font-bold rounded-xl text-sm hover:bg-emerald-300 transition-colors">
                    Redeem Points
                  </button>
                </div>
              </div>
            </div>

            {/* Top Right: Profile Summary Card */}
            <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm flex flex-col justify-center items-center text-center">
              <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center text-4xl mb-4 border border-emerald-100 shadow-sm">🌱</div>
              <h3 className="text-lg font-bold text-slate-900 mb-1">Eco Warrior</h3>
              <p className="text-sm text-slate-500 font-medium mb-4">Current Tier Status</p>
              <div className="w-full bg-slate-100 rounded-full h-2.5 mb-2">
                <div className="bg-emerald-400 h-2.5 rounded-full" style={{ width: '45%' }}></div>
              </div>
              <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">450 pts to Next Tier</p>
            </div>

            {/* Bottom Left: Camera Scanner */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm lg:col-span-2">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-slate-900">AI Scanner</h3>
                <button 
                  onClick={() => setCameraActive(!cameraActive)}
                  className={`px-4 py-2 rounded-lg text-sm font-bold transition-colors ${cameraActive ? 'bg-red-50 text-red-600' : 'bg-slate-900 text-white'}`}
                >
                  {cameraActive ? 'Close Camera' : 'Open Camera'}
                </button>
              </div>

              {cameraActive ? (
                <div className="bg-slate-900 rounded-2xl overflow-hidden aspect-video relative flex items-center justify-center mb-4">
                  <Webcam audio={false} ref={webcamRef} screenshotFormat="image/jpeg" videoConstraints={{ facingMode: "environment" }} className="w-full h-full object-cover" />
                  
                  {/* Target Overlay */}
                  <div className="absolute inset-0 border-[40px] border-black/40 pointer-events-none mix-blend-multiply"></div>
                  <div className="absolute w-48 h-48 border-2 border-emerald-400/50 rounded-2xl pointer-events-none"></div>

                  {classifying && (
                    <div className="absolute inset-0 bg-black/50 backdrop-blur-sm flex flex-col items-center justify-center text-white">
                      <div className="w-8 h-8 border-4 border-emerald-400 border-t-transparent rounded-full animate-spin mb-3"></div>
                      <p className="font-bold tracking-wider">ANALYZING...</p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl aspect-video flex flex-col items-center justify-center text-slate-400 mb-4">
                  <span className="text-3xl mb-2">📷</span>
                  <p className="font-semibold text-sm">Camera inactive</p>
                </div>
              )}

              {errorMsg && <p className="text-red-500 font-semibold text-sm mb-4 bg-red-50 p-3 rounded-lg">{errorMsg}</p>}

              <div className="flex flex-col sm:flex-row items-center gap-4">
                <button 
                  onClick={captureAndClassify}
                  disabled={!cameraActive || classifying}
                  className="w-full sm:w-auto px-6 py-3 bg-emerald-500 text-white font-bold rounded-xl disabled:opacity-50 disabled:bg-slate-300 hover:bg-emerald-600 transition-colors shadow-sm"
                >
                  Scan Waste Item
                </button>
                
                {lastResult && (
                  <div className="flex-1 w-full bg-slate-50 border border-slate-100 rounded-xl p-3 flex items-center justify-between">
                    <div>
                      <p className="text-xs text-slate-400 font-bold uppercase tracking-wider mb-0.5">Detected: <span className="text-slate-700">{lastResult.item}</span></p>
                      <p className={`text-sm font-bold ${lastResult.category === 'Recyclable' ? 'text-blue-600' : lastResult.category === 'Organic' ? 'text-green-600' : 'text-red-600'}`}>
                        {lastResult.category} Bin
                      </p>
                    </div>
                    <span className="font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md text-sm">+{lastResult.points} pts</span>
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Right: History Feed */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm flex flex-col h-[500px]">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-slate-900">Recent Scans</h3>
              </div>
              
              <div className="flex-1 overflow-y-auto pr-2 space-y-3">
                {user.history && user.history.length > 0 ? (
                  [...user.history].reverse().map((record, index) => (
                    <div key={index} className="flex items-center gap-4 p-3 bg-slate-50 rounded-2xl border border-slate-100 hover:bg-slate-100 transition-colors">
                      <div className="w-10 h-10 bg-white rounded-xl shadow-sm flex items-center justify-center text-lg border border-slate-100">
                        {CATEGORY_ICONS[record.category] || '♻️'}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold text-slate-900 truncate capitalize">{record.itemDetected}</p>
                        <p className="text-xs text-slate-500">{new Date(record.date).toLocaleDateString()} • {new Date(record.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-bold text-emerald-600">+{record.pointsEarned}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-slate-400">
                    <span className="text-3xl mb-2">🍃</span>
                    <p className="text-sm font-medium">No history yet.</p>
                  </div>
                )}
              </div>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
}