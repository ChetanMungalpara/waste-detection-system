'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function SignupPage() {
  const router = useRouter();
  const [formData, setFormData] = useState({ name: '', email: '', lpuUid: '', password: '' });
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); setMessage('');
    try {
      const res = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (res.ok) {
        setMessage('Success! Redirecting to login...');
        setTimeout(() => router.push('/login'), 2000);
      } else setMessage(data.message || 'Something went wrong.');
    } catch (error) {
      setMessage('Network error.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4 py-12">
      <div className="bg-white p-8 sm:p-12 rounded-[2rem] shadow-2xl shadow-slate-200/50 w-full max-w-lg border border-slate-100 relative overflow-hidden">
        
        {/* Subtle Background Header */}
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-br from-emerald-50 to-teal-50 -z-10"></div>

        <div className="w-16 h-16 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-2xl flex items-center justify-center text-white text-3xl shadow-xl shadow-emerald-500/30 mb-6 mx-auto transform -rotate-3">
          🌱
        </div>
        <h1 className="text-3xl font-extrabold text-slate-800 mb-2 text-center tracking-tight">Join EcoSort</h1>
        <p className="text-slate-500 font-medium text-center mb-8">Create your Circular Economy Profile</p>

        {message && (
          <div className={`p-4 rounded-xl mb-6 text-center font-bold text-sm border flex items-center justify-center gap-2 ${message.includes('Success') ? 'bg-emerald-50 text-emerald-600 border-emerald-200' : 'bg-red-50 text-red-600 border-red-100'}`}>
             {message.includes('Success') ? '✅' : '⚠️'} {message}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-1.5">
              <label className="text-sm font-bold text-slate-600">Full Name</label>
              <input type="text" required placeholder="John Doe" className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all font-medium text-slate-800 placeholder-slate-400" onChange={(e) => setFormData({ ...formData, name: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-bold text-slate-600">LPU UID</label>
              <input type="text" required placeholder="12000000" className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all font-medium text-slate-800 placeholder-slate-400" onChange={(e) => setFormData({ ...formData, lpuUid: e.target.value })} />
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-bold text-slate-600">University Email</label>
            <input type="email" required placeholder="name@lpu.in" className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all font-medium text-slate-800 placeholder-slate-400" onChange={(e) => setFormData({ ...formData, email: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-bold text-slate-600">Password</label>
            <input type="password" required placeholder="••••••••" className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all font-medium text-slate-800 placeholder-slate-400" onChange={(e) => setFormData({ ...formData, password: e.target.value })} />
          </div>
          
          <button type="submit" disabled={loading} className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-bold p-4 rounded-xl hover:from-emerald-400 hover:to-teal-400 transition-all shadow-lg shadow-emerald-500/25 mt-2 active:scale-[0.98] disabled:opacity-70 flex justify-center items-center">
            {loading ? 'Creating Profile...' : 'Register Profile'}
          </button>
        </form>

        <p className="mt-8 text-center text-sm font-medium text-slate-500">
          Already have an account? <Link href="/login" className="text-emerald-600 font-bold hover:text-emerald-500 transition-colors">Login here</Link>
        </p>
      </div>
    </div>
  );
}