import Link from 'next/link';

export default function HomePage() {
  return (
    <div className="relative min-h-screen flex items-center justify-center bg-[#0f172a] overflow-hidden selection:bg-emerald-500 selection:text-white">
      {/* Abstract Background Elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[40vw] h-[40vw] rounded-full bg-emerald-600/20 blur-[120px] mix-blend-screen pointer-events-none"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[30vw] h-[30vw] rounded-full bg-teal-500/20 blur-[100px] mix-blend-screen pointer-events-none"></div>
      
      <div className="relative z-10 w-full max-w-5xl px-6 py-12 mx-auto text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 mb-8 rounded-full bg-white/5 border border-white/10 backdrop-blur-md">
          <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="text-xs font-semibold tracking-wider text-emerald-100 uppercase">EcoSort System v2.0 Live</span>
        </div>

        <h1 className="text-5xl md:text-7xl font-black text-white tracking-tight leading-[1.1] mb-6">
          Smarter Waste.<br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400">Cleaner Future.</span>
        </h1>
        
        <p className="max-w-2xl mx-auto text-lg md:text-xl text-slate-400 font-medium mb-10 leading-relaxed">
          AI-powered waste classification at the source. Dispose correctly, earn reward points, and drive the circular economy directly from your campus.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link 
            href="/login" 
            className="w-full sm:w-auto px-8 py-4 text-sm font-bold text-[#0f172a] bg-emerald-400 rounded-xl hover:bg-emerald-300 transition-all shadow-[0_0_40px_-10px_rgba(52,211,153,0.5)] hover:scale-105 active:scale-95"
          >
            Access Dashboard
          </Link>
          <Link 
            href="/signup" 
            className="w-full sm:w-auto px-8 py-4 text-sm font-bold text-white bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 backdrop-blur-sm transition-all hover:scale-105 active:scale-95"
          >
            Create Profile
          </Link>
        </div>
      </div>
    </div>
  );
}