'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function LoginPage() {
  const router = useRouter();
  const [formData, setFormData] = useState({ identifier: '', password: '' });
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); setMessage('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (res.ok) {
        localStorage.setItem('ecoSortToken', data.token);
        localStorage.setItem('ecoSortUser', JSON.stringify(data.user));
        router.push('/dashboard');
      } else setMessage(data.message || 'Invalid credentials.');
    } catch (error) {
      setMessage('Network error.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4 sm:p-8">
      <div className="bg-white p-8 sm:p-12 rounded-[2rem] shadow-2xl shadow-slate-200/50 w-full max-w-md border border-slate-100 relative overflow-hidden">
        
        {/* Subtle Background Header */}
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-br from-emerald-50 to-teal-50 -z-10"></div>

        <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-2xl flex items-center justify-center text-white text-3xl shadow-xl shadow-emerald-500/30 mb-6 mx-auto transform rotate-3">
          ♻️
        </div>
        
        <h1 className="text-3xl font-extrabold text-slate-800 mb-2 text-center tracking-tight">Welcome Back</h1>
        <p className="text-slate-500 font-medium text-center mb-8">Login to your EcoSort Profile</p>

        {message && (
          <div className="p-4 rounded-xl mb-6 text-center font-semibold text-sm bg-red-50 text-red-600 border border-red-100 flex items-center justify-center gap-2 animate-pulse">
            <span>⚠️</span> {message}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-1.5">
            <label className="text-sm font-bold text-slate-600">LPU UID or Email</label>
            <input 
              type="text" 
              required 
              placeholder="e.g., 12000000 or email@lpu.in"
              className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all font-medium text-slate-800 placeholder-slate-400" 
              onChange={(e) => setFormData({ ...formData, identifier: e.target.value })} 
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-bold text-slate-600">Password</label>
            <input 
              type="password" 
              required 
              placeholder="••••••••"
              className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all font-medium text-slate-800 placeholder-slate-400" 
              onChange={(e) => setFormData({ ...formData, password: e.target.value })} 
            />
          </div>
          
          <button 
            type="submit" 
            disabled={loading} 
            className="w-full bg-slate-900 text-white font-bold p-4 rounded-xl hover:bg-slate-800 transition-all shadow-lg hover:shadow-xl mt-2 active:scale-[0.98] disabled:opacity-70 flex justify-center items-center"
          >
            {loading ? (
               <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
            ) : 'Secure Login'}
          </button>
        </form>

        <p className="mt-8 text-center text-sm font-medium text-slate-500">
          New to EcoSort? <Link href="/signup" className="text-emerald-600 font-bold hover:text-emerald-500 transition-colors">Create an account</Link>
        </p>
      </div>
    </div>
  );
}